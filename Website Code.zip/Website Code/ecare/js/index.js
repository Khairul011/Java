 var firebaseConfig =
  {
    apiKey: "AIzaSyAaEQbn4X7zCjdxGHULpPnSKRt5RQsLVpw",
    authDomain: "otp-login-8d85b.firebaseapp.com",
    databaseURL: "https://otp-login-8d85b-default-rtdb.firebaseio.com",
    projectId: "otp-login-8d85b",
    storageBucket: "otp-login-8d85b.appspot.com",
    messagingSenderId: "146467411673",
    appId: "1:146467411673:web:b96ff8db11fb9f310110c8",
    measurementId: "G-0502LVS5GG"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);