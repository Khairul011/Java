<?php
include "inc/header.php";
?>
   <!-- Navigation part start -->

   <nav class="navbar navbar-expand-md navbar-light bg-light ">
    <div class="container">
        <a class="navbar-brand" href="#home"><img src="img/logo.png"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#doctor">Doctor</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#patient">Patient</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-btn-custom" name="treatment" data-toggle="modal" href="https://tcbvideochat.000webhostapp.com/#7ce0bb">Treatment</a>
            </li>
           </ul>
        </div>
  </div>
</nav>
    <!-- Navigation part end -->
   

    <!-- Banner-section Start -->
    <div class="banner" id="home">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-6">

            <!-- <h3>Welcome To</h3> -->
            <h1>E-care</h1>
            <p>Duis aute irure dolor in reprehenderit in voluptate velit essesunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <ul class="nav justify-content-center banner-btn">
            <li class="nav-item">
              <a class="nav-link" data-toggle="modal"href="#clickformodal">Treatment</a>
            </li>
          </div>  
        </div>
      </div>
    </div>

    <!-- Banner-section end -->

    <!-- Banner-image-section start -->
    <section class="bannner-image parallax">
      <div class="container custom">
        <div class="row align-items-center">
          <div class="col-md-5">
            <div class="about-us wow fadeInUp">
                <h1>About Us</h1>
                <h4>Our delicious stroy</h4>
                <h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                  <a class="btn-custom justify-content-center btn"data-toggle="modal"href="#clickformodal">Treatment</a>
            </div>
            </div>
            <div class="col-md-6"> 
            <div class="col-md wow fadeInLeft">
              <img src="img/slider2.jpg" class="shadow">
            </div>
            <div class="col-md wow fadeInRight">
              <img src="img/slider3.jpg" class="shadow">
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Banner-image-section end -->


<!-- Feature-section start -->
 <div class="feature">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-6">
            
            <h1 class="wow fadeInLeft">Featured delicacies</h1>
            <h4 class="wow fadeInRight">Remort Patitent Monitoring System</h4>
            
            <h5 class="wow fadeInDown">We provide wireless patient monitoring Feature</h5>
            
          </div>  
        </div>
      </div>
    </div>
<!-- Feature-section End -->

 <!-- Doctor-section start -->
    <section class="doctor-section" id="doctor">
      <div class="container custom">
        <header>Our Doctor Team</header>
        <div class="row ">
            <div class="col-md-6 see">
              <div class="row mb-5">
                <div class="col-md-7">
                  <h1 class="wow fadeInLeft">Dr. Md. Abid Ibna Zahid</h1>
                  <h3 class="wow fadeInLeft">MBBS</h3>
                  <p class="wow fadeInLeft">Cardiologist</p>
                </div>
                <div class="col-md-5 wow fadeInRight">
                  <img src="img/d1.png">
                </div>
              </div>
          </div>
            <div class="col-md-6 see">
              <div class="row mb-5">
                <div class="col-md-7">
                  <h1 class="wow fadeInLeft">Dr. Rahima Farah</h1>
                  <h3 class="wow fadeInLeft">MBBS</h3>
                  <p class="wow fadeInLeft">Cardiologist</p>
                </div>
                <div class="col-md-5 wow fadeInRight">
                  <img src="img/d2.jpg">
                </div>
              </div>
          </div>

            <div class="col-md-6 see">
              <div class="row mb-5">
                <div class="col-md-7">
                  <h1 class="wow fadeInLeft">Dr. Md. Farabi Alam</h1>
                  <h3 class="wow fadeInLeft">MBBS</h3>
                  <p class="wow fadeInLeft">Neurologist</p>
                </div>
                <div class="col-md-5 wow fadeInRight">
                  <img src="img/d3.jpg">
                </div>
              </div>
          </div>

            <div class="col-md-6 see">
              <div class="row mb-5">
                <div class="col-md-7">
                  <h1 class="wow fadeInLeft">Dr. Md. Khairul Islam</h1>
                  <h3 class="wow fadeInLeft">MBBS</h3>
                  <p class="wow fadeInLeft">Gastrologist</p>
                </div>
                <div class="col-md-5 wow fadeInRight">
                  <img src="img/d1.png">
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>
    <!-- doctor-section end -->

    <!-- Patient-section start -->
 <div class="patient">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-6">
             
            <h4>Our Future Plan</h4>
            <h1>Covid Detection</h1>
            <h5>Everyday, 24/7</h5>
            <a class="btn-custom justify-content-center btn" data-toggle="modal"href="#clickformodal">Treatment</a>
          </div>  
        </div>
      </div>
    </div>
<!-- discount-section End -->

    <!-- work-section start -->
 <div class="work" id="patient">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-6">
         
		            <h1 class="wow fadeInLeft">They All <i class="fas fa-heart"></i> Our Patient</h1>
		            <p class="wow fadeInRight">Ullamco duis dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		             </div>
        </div>
     </div> 
</div>

<!-- work-section End -->

<!-- work-portfolio Start -->
<section class="portfolio">
      <div class="container custom">
        <div class="row">
            <div class="col-md wow fadeInLeft">
            <img src="img/avatar.png">
		     		<h3>"Lorem ipsum dolor sit amet!"</h3>
		     		<h4>Onu</h4>
            </div>
            <div class="col-md wow fadeInUp">
            <img src="img/avatar2.png">
		     		<h3>"Contrary to popular belief!"</h3>
		     		<h4>Khairul</h4>
            </div>
            <div class="col-md wow fadeInUp">
            <img src="img/avatar3.png">
		     		<h3>"There are many variations available!"</h3>
		     		<h4>Larua Z</h4>
            </div>
            <div class="col-md wow fadeInRight">
             <img src="img/avatar04.png">
		     		<h3>"Lorem ipsum dolor sit amet!"</h3>
		     		<h4>Farabi</h4>
            </div>
        </div>
      </div>
    </section>


<!-- work-portfolio End -->

 <!-- footer-section start -->
 <div class="footer" id="contact">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-6">
             <h1>Contact Us</h1>
              
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting.standard it to make a type specimen book. It has survived not only five centuries, </p>
            <a class="btn-custom justify-content-center  btn"data-toggle="modal"href="#clickformodal">Treatment</a>
            <h2>Or Call us:123 456 7890</h2>
		     
		     <ul class="nav">
		     	<li class="nav-item">
		     		<div class="wow fadeInLeft">
		     		<a href="#"><i class="fab fa-facebook-f"></i></a>
		     		</div>
		     	</li>
		     	<li class="nav-item">
		     		<div class="wow fadeInLeft">
		     		<a href="#"><i class="fab fa-twitter"></i></a>
		     		</div>
		     	</li>
		     	<li class="nav-item">
		     		<div class="wow fadeInUp">
		     		<a href="#"><i class="fab fa-facebook-f"></i></a>
		     		</div>
		     	</li>
		     	<li class="nav-item">
		     		<div class="wow fadeInRight">
		     		<a href="#"><i class="fab fa-twitter"></i></a>
		     		</div>
		     	</li>
		     	<li class="nav-item">
		     		<div class="wow fadeInRight">
		     		<a href="#"><i class="fab fa-google-plus-g"></i></a>
		     		</div>
		     	</li>
		     </ul>
		    </div>
        </div>
       </div>
        <div class="Copyright">
		     	<div class="col-md-6">
		     		<h6>Copyright 2021 Ecare|<span>credits</span></h6>
		     	</div>
		     	<div class="col-md-6">
		     		<h6>powered by <span>Ecare</span></h6>
		     	</div>
		     </div>
     
</div>
 

<div class="modal fade" id="clickformodal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header justify-content-center">
				<h3>Sign Up</h3>
			</div>
			<div class="modal-body">
			<form>
				<div class="form-group">
				<input type="text"class="form-control" placeholder="Full Name">
				</div>
        <div class="form-group">
        <input type="text"class="form-control" placeholder="Email Address">
        </div>
        <div class="form-group">
        <input type="text"class="form-control" placeholder="Password">
        </div>
						<div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				        <button type="button" class="btn btn-primary">Sign Up</button>
				      </div>
			</form>
			</div>
		</div>
	</div>
</div>

<?php
include "inc/footer.php";
?>