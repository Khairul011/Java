<?php

include "inc/header.php" ;



if(isset($_POST['addpres']))
{
  
  $name = $_POST['name'];
  $age = $_POST['age'];
  $blood = $_POST['blood'];
  $m1name = $_POST['m1name'];
  $m2name = $_POST['m2name'];
  $m3name = $_POST['m3name'];


  $postData = [
   
    'name'=>$name,
    'age'=>$age,
    'blood'=>$blood,
    'm1name'=>$m1name,
    'm2name'=>$m2name,
    'm3name'=>$m3name,
];

  $ref_table="pescription";
  $postRef = $database->getReference($ref_table)->push($postData);



  if($postRef){
    echo"ok";
    header('Location: patient.php');
  }
  else{
    $_SESSION['status'] = "Data not Insert Successfully";
    header("Location: dashboard.php");
  }


}

?>