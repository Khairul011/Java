<?php
include "inc/header.php" ;
?>
   <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
		<div class="prescription">
			<div class="container">
			<div class="header">	

				  <?php
                $ref_table = "doctor";
                $fetchdata = $database->getReference($ref_table)->getValue();;

                if($fetchdata != 0){
                  foreach ($fetchdata as $key => $row) 
                  {
                  	
        
                    ?>

                     

                  <?php

                  }

                }
                else{
                  ?>
                  <h1>No Doctor Found</h1>

                  <?php

                }

                ?>
			<!-- <div class="header"> -->
				<h1>Ecare Online Patient Monitoring System</h1>
				<h6>Bashundhara R/A, Dhaka, Bangladesh</h6>
				<h3><?= $row['name'];?></h3>
				<h5><?= $row['specialist'];?></h5>
			<!-- </div> -->
			</div>
			
			<div class="date">


				 <?php
                $ref_table = "doctor";
                $fetchdata = $database->getReference($ref_table)->getValue();;
                $i=0;
                if($fetchdata != 0){
                  foreach ($fetchdata as $key => $row) 
                  {
                  	$i++;
                    
        			}
        		}
                    ?>
				
					<h6>Serial No.<?php echo $i;?></h6>
					<h4>Date: <?php echo date("d-m-Y")?> </h4>
			</div>    
			

			<form action="treatment.php" method="POST">
		        <div class="patient">

		        	<div class="row">

		        		<div class="col-md-3">
			        		<div class="exam">
			        			<h1>Report</h1>
			        			
			        				<textarea name="report" placeholder="Write here"></textarea>
			        			
			        		</div>
			        	</div>

						<div class="divider"></div>  

			        	<div class="col-md">
				        	<div class="info">
				        		<div class="row">
					        		<div class="col-md-6">
			                            <div class="input-group mb-3">
			                              <input type="text" class="form-control" name="name" placeholder="Patient Name">
			                            </div>
			                          </div>
					        		<div class="col-md-3">
			                            <div class="input-group mb-3">
			                              <input type="text" class="form-control" name="age" placeholder="Age">
			                            </div>
			                          </div>
			                          <div class="col-md-3">
			                              <div class="input-group mb-3">
			                              <input type="text" class="form-control" name="blood" placeholder="Blood Group">
			                            </div>
			                          </div>
				        		</div>
				        	</div>
				        	<div class="rx">
							<h1>R <span>X</span></h1>
						</div>
				        	<div class="info">
				        		<div class="row">
					        		<div class="col-md-9">
			                            <div class="input-group mb-3">
			                              <input type="text" class="form-control" name="m1name" placeholder="Medisine Name">
			                            </div>
			                          </div>
				        		</div>
				        	</div>
				        	<div class="info">
				        		<div class="row">
					        		<div class="col-md-9">
			                            <div class="input-group mb-3">
			                              <input type="text" class="form-control" name="m2name" placeholder="Medisine Name">
			                            </div>
			                          </div>
				        		</div>
				        	</div>
				        	<div class="info">
				        		<div class="row">
					        		<div class="col-md-9">
			                            <div class="input-group mb-3">
			                              <input type="text" class="form-control" name="m3name" placeholder="Medisine Name">
			                            </div>
			                          </div>
				        		   </div>
				        	    </div>
				            </div>		
				 	    </div>   
			        	
					<div class="pes_footer">
						
					<div class="row">
						<div class="sign">
				          	<form>
			        				<textarea placeholder= "Doctor's Signature"></textarea>
			        			</form>
				        	</div> 
				        <!-- /.col -->
				        <div class="col-md-3 bb">
				        	
				            <input type="submit" name="addpres" value="Send" class="btn btn-primary btn-block" style="
									    width: 58px;
									    margin: auto;
									">
				        </div>
				          <!-- /.col -->  
					</div>
					</div>
							   
			          
				          
					</div>    	
		      	</form>
		    </div>	
		</div>
	</div>
</div>



 <?php
include "inc/footer.php";
?>
