<?php
include "inc/header.php" ;
?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Settings</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Settings</li>
            </ol>
          </div><!-- /.col -->


          <div class="settings">
                         <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
        <div class="col-md">
          <table class="table table-dark">
            <thead>
              <tr>
                <th scope="col">SI</th>
                <th scope="col">Name</th>
                <th scope="col">User_name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone Number</th>
                <th scope="col">Photo</th>
                <th scope="col">User Role</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>

              <?php

              $query = "SELECT * FROM user";

              $allUser = mysqli_query($db, $query);
              $i =0;
              while ($row = mysqli_fetch_assoc($allUser)){
                $id        = $row['user_id'];
                $name      = $row['name'];
                $user_name = $row['user_name'];
                $email     = $row['email'];
                $phone     = $row['phone'];
                $image     = $row['image'];
                $role      = $row['user_role'];
                $i++;
              ?>
              <tr>
                <th scope="row"><?php echo $i?></th>
                <td><?php echo $name?></td>
                <td><?php echo $user_name?></td>
                <td><?php echo $email?></td>
                <td><?php echo $phone?></td>
                <td><img src="img/<?php echo $image?>" height="50" weight="50"> </td>
                <td><?php 
                  if($role == 0){?>
                    <span class="badge badge-success">Doctor</span>
                 <?php }else{?>
                  <span class="badge badge-primary">Patient</span>
                  <?php }
                  ?>
                </td>
                <td>
                      <div class="action-item">
                          <ul>
                            <li><a href="update.php?edit=<?php echo $id;?>"><i class="fa fa-edit"></i></a></li>
                            <li>
                              <a href="settings.php?delete=<?php echo $id;?>">
                                <i class="fa fa-trash"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                </td>
             </tr>
                  <?php
                }
                ?>
             
            </tbody>
          </table>
                  </div>

           <?php 

          if(isset($_GET['delete'])){
            $userDelete = $_GET['delete'];

            $query = "SELECT * FROM user WHERE user_id='$userDelete'";

            $result = mysqli_query($db,$query);

            while ($row = mysqli_fetch_assoc($result)) {
              # code...
              $name = $row['image'];
            }

            // unlink("img/$name");


            $query = "DELETE FROM user WHERE user_id='$userDelete'";

            $result = mysqli_query($db,$query);

            if($result){
              header('Location: settings.php');
            }else{
              die("".mysqli_error());
            }
          }
        ?>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content --> 
 </div>
   




        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 </div>
<?php
include "inc/footer.php";
?>
