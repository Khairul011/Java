<?php
include "inc/header.php" ;
?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Patient</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Patient</li>
            </ol>
          </div><!-- /.col -->

          <section class="patient">
           <div class="container">
              <div class="row">
                <div class="col-md-4 ">
                  <div class="patient_info">
                     <div class="p_img">
                    <img src="img/patient/avatar04.png" class="w-100">
                    </div>
                    <div class="p_header">
                      <h1>Patient</h1>
                      <h2>Topu</h2>
                      <a href="#">treatment</a>
                      <a href="prescription.php">prescription</a>

                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="info">
                    <h2>Sex: <span>Male</span></h2>
                      <h2>Age: <span>35</span></h2>
                      <h2>Blood: <span>B-</span></h2>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="info">
                    <h2>Check-in <span>22 jan,2021</span></h2>
                    <h2>Dept: <span>Gastrologist</span></h2>
                    <h2>Doctor: <span>Dr. Md. Khairul Islam</span></h2>
                  </div>
                </div>
            </div>
           </div>
          </section>

     
          <div class="data w-100">
            <div class="container">
              <header><h1>Patient Info</h1></header>
              <div class="row">

                <div class="col-md-6">
                  <h2>Heart Rate</h2>
                      <!-- Table Start -->
                <table class="table">
                  <thead class="thead-dark"  style="text-align: center;">
                    <tr>
                      
                      <th scope="col">Temp.</th>
                      <th scope="col">Heart rate</th>
                    </tr>
                  </thead>
                  <tbody>
                     <td> <h4 style="text-align: center; position: relative;">Temp. = 041 <span style="position: absolute; top: 0px; font-size: 10px;margin-left: -6px;">0 </span>C</h4></td>
                     <td>   <h4 style="text-align: center;">Heart rate = 073 B/M</h4></td>
                  </tbody>
                </table>

             <!-- Table End -->
                 
                
                  <!-- <img src="img/data/heart.png" class="w-100"> -->
                </div>
                <div class="col-md-6">
                  <h2>Temperature With SpO2</h2>

                           <!-- Table Start -->
                <table class="table">
                  <thead class="thead-dark"  style="text-align: center;">
                    <tr>
                      
                      <th scope="col">Room Temperature</th>
                      <th scope="col">Room Humidity</th>
                      <th scope="col">BPM</th>
                      <th scope="col">SpO2</th>
                      <th scope="col">Body Temperature</th>
                    </tr>
                  </thead>
                  <tbody>
                     
                     <td><h4 style="text-align: center;position: relative;"> 25.00<span style="position: absolute; top: 0px; font-size: 10px;margin-left: -2px;">0 </span>C</h4></td>
                     <td>  <h4 style="text-align: center;">30.00%</h4></td>
                     <td>  <h4 style="text-align: center;"> 89.96</h4></td>
                     <td>  <h4 style="text-align: center;">97.00%</h4></td>
                     <td>  <h4 style="text-align: center; position: relative;">30.06<span style="position: absolute; top: 0px; font-size: 10px;margin-left: -2px;">0 </span>C</h4></td>


                    
                  </tbody>
                </table>

             <!-- Table End -->
                 
               
                 
                </div>
                <div class="col">
                  <h2>Body Temperature</h2>

                            <!-- Table Start -->
                <table class="table">
                  <thead class="thead-dark"  style="text-align: center;">
                    <tr>
                      
                      <th scope="col">Body Temperature</th>
                    </tr>
                  </thead>
                  <tbody>   
                     <td>  <h4 style="text-align: center;">33 . 26 , 86 . 51 , 0</h4></td>
                    
                  </tbody>
                </table>

             <!-- Table End -->
                 

                  
          
                </div>
              </div>
            </div>
          </div>

 <div class="next_patient">
              <div class="container">
                <div class="row">
                  <header><h1>Next Patient</h1></header>
               
                  
                  <div class="col">
                    <div class="patient_info">
                       <div class="p_img">
                      <img src="img/patient/avatar5.png" class="w-100">
                      </div>
                      <div class="p_header">
                        
                        <h2>Farabi</h2>
                        <a href="farabi.php">view profile</a>
                      </div>
                    </div>
                  </div>
                 
                </div>
              </div>
            </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 
<?php
include "inc/footer.php";
?>







