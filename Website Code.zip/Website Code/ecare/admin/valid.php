<?php

include "inc/header.php" ;
?>

<?php

if(isset($_POST['login']))
{
      $ref_table = "doctor";
        $fetchdata = $database->getReference($ref_table)->getValue();;

          if($fetchdata != 0){
            foreach ($fetchdata as $key => $row) {
              $name = $row['name'];
              $email = $row['email'];
              $phone = $row['phone'];
              $specialist = $row['specialist'];
              $password = $row['password'];
         

              if($email==$email && $password==$password){
                echo"Log In sussessfully";
                header('Location: dashboard.php');
              }
              else{
                $_SESSION['status'] = "Data not Insert Successfully";
                header("Location: dashboard.php");
  }

   }         
 }
}

?>

