package com.amarapps.healthmonitoring.doctor;

public class prescripClass {

    private String name;
    private String age;
    private String blood;
    private String m1Name;
    private String time1;
    private String m2Name;
    private String time2;
    private String m3Name;
    private String time3;

    public prescripClass()
    {

    }

    public prescripClass(String name, String age, String blood, String m1Name, String time1, String m2Name, String time2, String m3Name, String time3) {
        this.name = name;
        this.age = age;
        this.blood = blood;
        this.m1Name = m1Name;
        this.time1 = time1;
        this.m2Name = m2Name;
        this.time2 = time2;
        this.m3Name = m3Name;
        this.time3 = time3;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBlood() {
        return blood;
    }

    public void setBlood(String blood) {
        this.blood = blood;
    }

    public String getM1Name() {
        return m1Name;
    }

    public void setM1Name(String m1Name) {
        this.m1Name = m1Name;
    }

    public String getTime1() {
        return time1;
    }

    public void setTime1(String time1) {
        this.time1 = time1;
    }

    public String getM2Name() {
        return m2Name;
    }

    public void setM2Name(String m2Name) {
        this.m2Name = m2Name;
    }

    public String getTime2() {
        return time2;
    }

    public void setTime2(String time2) {
        this.time2 = time2;
    }

    public String getM3Name() {
        return m3Name;
    }

    public void setM3Name(String m3Name) {
        this.m3Name = m3Name;
    }

    public String getTime3() {
        return time3;
    }

    public void setTime3(String time3) {
        this.time3 = time3;
    }
}
