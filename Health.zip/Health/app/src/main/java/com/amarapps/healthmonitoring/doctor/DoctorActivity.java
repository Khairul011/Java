package com.amarapps.healthmonitoring.doctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.amarapps.healthmonitoring.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DoctorActivity extends AppCompatActivity {

    private ListView listView;
    DatabaseReference databaseReference;
    FirebaseDatabase firebaseDatabase;

    private List<doctorClass> doctorClassList;
    private doctorAdaptor doctorAdaptor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctor_layout);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("doctor");
        doctorClassList = new ArrayList<>();
        doctorAdaptor = new doctorAdaptor(DoctorActivity.this, doctorClassList);

        listView = findViewById(R.id.List);
        Query pendingTestsQuery = databaseReference.orderByChild("name").equalTo("Md. Abid Ibna Zahid");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //  Log.e("LOGGGGG","--:"+dataSnapshot.getChildren());
                // String value = dataSnapshot.getValue(String.class);

                // Log.e("LOGGGGG","--:"+value);
                doctorClassList.clear();
                for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {

                    Map<String, Object> map1 = (Map<String, Object>) dataSnapshot2.getValue();

                    try {
                        JSONObject topobj = new JSONObject(map1);
                        String d_email = topobj.getString("email");
                        String d_name = topobj.getString("name");
                        String d_spacial = topobj.getString("specialist");
                        doctorClass doctor = new doctorClass(d_name, d_spacial,d_email);
                        doctorClassList.add(doctor);
                        Log.d("TAGGG", "Value is: " + d_spacial);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                    // Log.d(TAG, "Value is: " + map);
                    //   String value = dataSnapshot1.getValue(String.class);
                    //User user = dataSnapshot1.getValue(User.class);
                    Log.e("LOGGGGG", "Value is: " + map1);


                }
                listView.setAdapter(doctorAdaptor);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("LOGGGGG", "--:" + error.toString());

            }
        });
    }

}