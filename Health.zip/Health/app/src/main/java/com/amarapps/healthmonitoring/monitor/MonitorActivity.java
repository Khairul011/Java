package com.amarapps.healthmonitoring.monitor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.amarapps.healthmonitoring.R;

public class MonitorActivity extends AppCompatActivity {

TextView temp, hum, hr, ecg;
Button monitor;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitor);

        temp = (TextView) findViewById(R.id.m_temp);
        hum = (TextView) findViewById(R.id.m_hum);
        hr = (TextView) findViewById(R.id.m_hr);
        ecg = (TextView) findViewById(R.id.m_ecg);
        monitor = (Button) findViewById(R.id.monitor_btn);


    }
}