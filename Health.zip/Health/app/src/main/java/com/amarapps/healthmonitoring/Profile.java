package com.amarapps.healthmonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Profile extends AppCompatActivity {

    TextView name, pho, addr, blood, age,email, other, edit_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
//        name = findViewById(R.id.P_name);
//        pho = findViewById(R.id.P_phone);
//        addr = findViewById(R.id.P_address);
//        blood = findViewById(R.id.P_blood);
//        age = findViewById(R.id.P_age);
//        email = findViewById(R.id.P_email);
//        other = findViewById(R.id.P_other);
//
//        name.setText(new DataPreference(Profile.this).getUserName());
//        pho.setText(new DataPreference(Profile.this).getPhone());






    }
}