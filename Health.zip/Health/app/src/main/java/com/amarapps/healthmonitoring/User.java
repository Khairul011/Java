package com.amarapps.healthmonitoring;



public class User {
    private String userName;
    private String phone;
    private String pass;


    public User(String userName, String phone, String pass) {

        this.userName = userName;
        this.phone = phone;
        this.pass = pass;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
