package com.amarapps.healthmonitoring;

import android.app.ProgressDialog;
import android.content.Intent;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class RegisterActivity extends AppCompatActivity {
    EditText username1,edtPhone,password;
    TextView AccountExists;
    Button register, saveData, loadData;
    DatabaseReference databaseReference;

    private ProgressDialog loadingBar;//Used to show the progress of the registration process
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databaseReference = FirebaseDatabase.getInstance().getReference("user");
        edtPhone = (EditText) findViewById(R.id.edtPhone);
        username1 = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.Password2);
        register = (Button) findViewById(R.id.submit_btn);
        saveData = (Button)findViewById(R.id.save_btn);
        loadData = (Button)findViewById(R.id.load_btn);
        AccountExists = (TextView) findViewById(R.id.Already_link);
        loadingBar = new ProgressDialog(this);
        //When user has  an account already he should be sent to login activity.

        AccountExists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);            }

        });

        loadData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this,Details.class);
                startActivity(intent);
            }
        });

        saveData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // savedata();

            }
        });

        //When user clicks on register create a new account for user
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createNewAccount();
            }
        });
    }

    private void createNewAccount() {
        String email = edtPhone.getText().toString().trim();
        String pwd = password.getText().toString();
        if(TextUtils.isEmpty(email))
        {
            Toast.makeText(RegisterActivity.this,"Please enter email id",Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(pwd))
        {
            Toast.makeText(RegisterActivity.this,"Please enter password",Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(RegisterActivity.this,"User Successfully Created",Toast.LENGTH_SHORT).show();
            sendUserToLoginActivity();
        }
    }

    private void sendUserToLoginActivity() {
        //This is to send user to Login Activity.
        String phoneNo = edtPhone.getText().toString().trim();
        String user = username1.getText().toString().trim();
        String pass = password.getText().toString().trim();
        Intent loginIntent = new Intent(RegisterActivity.this,OtpVerification.class);
        loginIntent.putExtra("Phone",phoneNo);
        loginIntent.putExtra("user",user);
        loginIntent.putExtra("pass",pass);
       // String phpn=getIntent().getStringExtra("Phone");
        startActivity(loginIntent);
    }

//    void savedata() {
//        String phoneNo = edtPhone.getText().toString().trim();
//        String usr = username1.getText().toString().trim();
//        String pass = password.getText().toString().trim();
//
//        String key = databaseReference.push().getKey();
//        User user = new User(usr, phoneNo, pass);
//        databaseReference.child(key).setValue(user);
//        Toast.makeText(RegisterActivity.this, "Saved", Toast.LENGTH_LONG).show();
//
//
//    }
}
