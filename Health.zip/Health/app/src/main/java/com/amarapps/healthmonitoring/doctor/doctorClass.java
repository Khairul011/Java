package com.amarapps.healthmonitoring.doctor;

public class doctorClass {

    private String name;
    private String special;
    private String email;

    public doctorClass()
    {

    }

    public doctorClass(String name, String special, String email) {
        this.name = name;
        this.special = special;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecial() {
        return special;
    }

    public void setSpecial(String special) {
        this.special = special;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

