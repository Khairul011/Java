package com.amarapps.healthmonitoring;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class EditProfile extends AppCompatActivity {
    TextView t1, t2;
    EditText t3, t4, t5, t6, t7, t8, t9, t10;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        databaseReference = FirebaseDatabase.getInstance().getReference();



        t1 = (TextView) findViewById(R.id.t1);
        t2 = (TextView) findViewById(R.id.t2);
        t3 = (EditText) findViewById(R.id.t3);
        t4 = (EditText) findViewById(R.id.t4);
        t5 = (EditText) findViewById(R.id.t5);
        t6 = (EditText) findViewById(R.id.t6);
        t7 = (EditText) findViewById(R.id.t7);
        t8 = (EditText) findViewById(R.id.t8);
        t9 = (EditText) findViewById(R.id.t9);
        t10 = (EditText) findViewById(R.id.t10);

        t1.setText(new DataPreference(EditProfile.this).getUserName());
        t2.setText(new DataPreference(EditProfile.this).getPhone());
        t3.setText(new DataPreference(EditProfile.this).getAddress());
        t4.setText(new DataPreference(EditProfile.this).getBlood());
        t5.setText(new DataPreference(EditProfile.this).getAge());
        t6.setText(new DataPreference(EditProfile.this).getGender());
        t7.setText(new DataPreference(EditProfile.this).getTemp());
        t8.setText(new DataPreference(EditProfile.this).getHeartRate());
        t9.setText(new DataPreference(EditProfile.this).getSpo2());
        t10.setText(new DataPreference(EditProfile.this).getEcg());




//        sendData();
    }



    public void sendData(View view) {

        String name = t1.getText().toString().trim();
        String phone = t2.getText().toString().trim();
        String address = t3.getText().toString().trim();
        String blood = t4.getText().toString().trim();
        String age = t5.getText().toString().trim();
        String gender = t6.getText().toString().trim();
        String temp = t7.getText().toString().trim();
        String heartRate = t8.getText().toString().trim();
        String spo2 = t9.getText().toString().trim();
        String ecg = t10.getText().toString().trim();



        Information obj = new Information(name, phone, address, blood, age, gender, temp, heartRate, spo2, ecg);
        FirebaseDatabase db = FirebaseDatabase.getInstance();

        DatabaseReference nood = db.getReference("info");
        nood.child(phone).setValue(obj);

//        t1.setText(name);
//        t2.setText(phone);
//        t3.setText(address);
//        t4.setText(blood);
//        t5.setText(age);
//        t6.setText(gender);
//        t7.setText(email);
//        t8.setText(other);

        Toast.makeText(getApplicationContext(), "Information Saved", Toast.LENGTH_SHORT).show();
        retriveData();

        finish();
    }

    void retriveData() {

        databaseReference.child("info").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                Log.i("LOGGGGG", "---300-" + dataSnapshot.toString());
                //     Log.i("LOGGGGG", "---300-" + input1.toString());
                //     Log.i("LOGGGGG", "---300-" + input2.toString());
                //if (dataSnapshot.child(input1).child("password").getValue(String.class).equals(input2)) {
                // if (dataSnapshot.child(input1).exists()) {
                boolean isLogin = false;
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                    Map<String, Object> map = (Map<String, Object>) dataSnapshot1.getValue();

                    try {
                        JSONObject topobj = new JSONObject(map);
                        String name = topobj.getString("name");
                        String phone = topobj.getString("phone");

                        String address = topobj.getString("address");
                        String blood = topobj.getString("blood");
                        String age = topobj.getString("age");
                        String gender = topobj.getString("gender");
                        String temp = topobj.getString("temp");
                        String heartRate = topobj.getString("heartRate");
                        String spo2 = topobj.getString("spo2");
                        String ecg = topobj.getString("ecg");

                        if (name.equals(new DataPreference(EditProfile.this).getUserName()) & phone.equals(new DataPreference(EditProfile.this).getPhone())) {
                            new DataPreference(EditProfile.this).setUserName(name);
                            new DataPreference(EditProfile.this).setPhone(phone);
                            new DataPreference(EditProfile.this).setAddress(address);
                            new DataPreference(EditProfile.this).setBlood(blood);
                            new DataPreference(EditProfile.this).setAge(age);
                            new DataPreference(EditProfile.this).setGender(gender);
                            new DataPreference(EditProfile.this).setTemp(temp);
                            new DataPreference(EditProfile.this).setHeartRate(heartRate);
                            new DataPreference(EditProfile.this).setSpo2(spo2);
                            new DataPreference(EditProfile.this).setEcg(ecg);

                        }
////                        if (name.equals(input1) && phone.equals(input1)) {
////                            sendToMainActivity();
////                            break;
//                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}