package com.amarapps.healthmonitoring.ui.profile;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.amarapps.healthmonitoring.DataPreference;
import com.amarapps.healthmonitoring.EditProfile;
import com.amarapps.healthmonitoring.LoginActivity;
import com.amarapps.healthmonitoring.R;
import com.amarapps.healthmonitoring.RegisterActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;


public class ProfileFragment extends Fragment {
    TextView name, pho, addr, blood, age, gender, temp, heartRate, spo2, ecg, Edt_btn;
    DatabaseReference databaseReference;







    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_profile, container, false);

        databaseReference = FirebaseDatabase.getInstance().getReference();

        name = v.findViewById(R.id.P_name);
        pho = v.findViewById(R.id.P_phone);
        addr = v.findViewById(R.id.P_address);
        blood = v.findViewById(R.id.P_blood);
        age = v.findViewById(R.id.P_age);
        gender = v.findViewById(R.id.P_gender);
        temp = v.findViewById(R.id.P_temp);
        heartRate = v.findViewById(R.id.P_hr);
        spo2 = v.findViewById(R.id.P_spo2);
        ecg = v.findViewById(R.id.P_ecg);
        Edt_btn = v.findViewById(R.id.edt_btn);







        Edt_btn = (Button) v.findViewById(R.id.edt_btn);
        Edt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(),EditProfile.class));
            }
        });
        return v;


    }


    @Override
    public void onResume() {

        name.setText(new DataPreference(getActivity()).getUserName());
        pho.setText(new DataPreference(getActivity()).getPhone());
        addr.setText(new DataPreference(getActivity()).getAddress());
        blood.setText(new DataPreference(getActivity()).getBlood());
        gender.setText(new DataPreference(getActivity()).getGender());
        age.setText(new DataPreference(getActivity()).getAge());
        temp.setText(new DataPreference(getActivity()).getTemp());
        heartRate.setText(new DataPreference(getActivity()).getHeartRate());
        spo2.setText(new DataPreference(getActivity()).getSpo2());
        ecg.setText(new DataPreference(getActivity()).getEcg());


        super.onResume();
    }
}