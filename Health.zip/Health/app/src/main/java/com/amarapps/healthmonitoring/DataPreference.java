package com.amarapps.healthmonitoring;

import android.content.Context;
import android.content.SharedPreferences;

public class DataPreference {

    SharedPreferences sharedPreferences;
    public SharedPreferences.Editor editor;
    public Context context;
    int PRIVATE_MODE = 0;


    public DataPreference(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("test", PRIVATE_MODE);
        editor = sharedPreferences.edit();
    }

    public String getUserName() {
        return sharedPreferences.getString("UserName", "");
    }

    public void setUserName(String username) {
        editor.putString("UserName", username);
        editor.apply();

    }

    public String getPhone() {
        return sharedPreferences.getString("phone", "");
    }

    public void setPhone(String phone) {
        editor.putString("phone", phone);
        editor.apply();

    }

    public String getAddress() {
        return sharedPreferences.getString("address", "");
    }

    public void setAddress(String address) {
        editor.putString("address", address);
        editor.apply();

    }
    public String getBlood() {
        return sharedPreferences.getString("blood", "");
    }

    public void setBlood(String blood) {
        editor.putString("blood", blood);
        editor.apply();

    }
    public String getAge() {
        return sharedPreferences.getString("age", "");
    }

    public void setAge(String age) {
        editor.putString("age", age);
        editor.apply();

    }
    public String getGender() {
        return sharedPreferences.getString("gender", "");
    }

    public void setGender(String gender) {
        editor.putString("gender", gender);
        editor.apply();

    }
    public String getTemp() {
        return sharedPreferences.getString("temp", "");
    }

    public void setTemp(String temp) {
        editor.putString("temp", temp);
        editor.apply();

    }
    public String getHeartRate() {
        return sharedPreferences.getString("heartRate", "");
    }

    public void setHeartRate(String heartRate) {
        editor.putString("heartRate", heartRate);
        editor.apply();

    }
    public String getSpo2() {
        return sharedPreferences.getString("spo2", "");
    }

    public void setSpo2(String spo2) {
        editor.putString("spo2", spo2);
        editor.apply();

    }
    public String getEcg() {
        return sharedPreferences.getString("ecg", "");
    }

    public void setEcg(String ecg) {
        editor.putString("ecg", ecg);
        editor.apply();

    }

    public String getName() {
        return sharedPreferences.getString("name", "");
    }

    public void setName(String name) {
        editor.putString("name", name);
        editor.apply();

    }
    public String getM1name() {
        return sharedPreferences.getString("m1name:", "");
    }

    public void setM1name(String m1name) {
        editor.putString("m1name:", m1name);
        editor.apply();

    }
    public String getTime1() {
        return sharedPreferences.getString("time1:", "");
    }

    public void setTime1(String time1) {
        editor.putString("time1:", time1);
        editor.apply();

    }


    public String getM2name() {
        return sharedPreferences.getString("m1name:", "");
    }

    public void setM2name(String m2name) {
        editor.putString("m2name:", m2name);
        editor.apply();

    }
    public String getTime2() {
        return sharedPreferences.getString("time2:", "");
    }

    public void setTime2(String time2) {
        editor.putString("time2:", time2);
        editor.apply();

    }

    public String getM3name() {
        return sharedPreferences.getString("m3name:", "");
    }

    public void setM3name(String m3name) {
        editor.putString("m3name:", m3name);
        editor.apply();

    }
    public String getTime3() {
        return sharedPreferences.getString("time3:", "");
    }

    public void setTime3(String time3) {
        editor.putString("time3:", time3);
        editor.apply();

    }



}
