package com.amarapps.healthmonitoring;
import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.util.ArrayDeque;
import java.util.concurrent.TimeUnit;

public class OtpVerification extends AppCompatActivity {
    DatabaseReference databaseReference;

    //variable for FirebaseAuth class
    private FirebaseAuth mAuth;
    //variable for our text input field for phone and OTP.
    private EditText edtPhone, edtOTP;
    //buttons for generating OTP and verifying OTP
    private Button verifyOTPBtn, generateOTPBtn;
    //string for storing our verification ID
    private String verificationId;
    String code = "";
    private String phpn, userName, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        phpn = getIntent().getStringExtra("Phone");
        userName = getIntent().getStringExtra("user");
        password = getIntent().getStringExtra("pass");
        databaseReference = FirebaseDatabase.getInstance().getReference("user");

        //below line is for getting instance of our FirebaseAuth.
        mAuth = FirebaseAuth.getInstance();
        // Log.i("DDDDDDDD", "+8801612818756");
        edtPhone = findViewById(R.id.edtPhone);
        verifyOTPBtn = findViewById(R.id.verifyOTPBtn);
        edtOTP = findViewById(R.id.edtOTP);
        edtPhone.setText(phpn);
        sendVerificationCode("+88" + phpn);
        verifyOTPBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyCode(edtOTP.getText().toString().trim());
            }
        });

    }



    private void verifyCode(String code) {
        Log.e("TAGGG",":"+code);
       PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        //Log.e("TAGGG",":"+code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {



                            savedata();

                        } else {
                            Toast.makeText(OtpVerification.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void sendVerificationCode(String number) {

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallBack
        );

    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            Log.i("TAGGG","verificationId:-"+s);
            verificationId = s;

        }

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            if (code != null) {
                edtOTP.setText(code);
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(OtpVerification.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };


    void savedata() {

        String key = databaseReference.push().getKey();
        User user = new User(userName, phpn, password);
        databaseReference.child(key).setValue(user);
        Toast.makeText(OtpVerification.this, "Saved", Toast.LENGTH_LONG).show();

        Intent intent = new Intent(OtpVerification.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }


}