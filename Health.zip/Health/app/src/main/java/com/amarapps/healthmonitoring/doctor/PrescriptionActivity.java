package com.amarapps.healthmonitoring.doctor;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.amarapps.healthmonitoring.DataPreference;
import com.amarapps.healthmonitoring.EditProfile;
import com.amarapps.healthmonitoring.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PrescriptionActivity extends AppCompatActivity {
    private ListView listView;
    DatabaseReference databaseReference;
    FirebaseDatabase firebaseDatabase;

    private ArrayList<prescripClass> prescripClassList;
    private prescripAdapter prescripAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prescrip_layout);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("pescription");
        prescripClassList = new ArrayList<>();
        prescripAdapter = new prescripAdapter(PrescriptionActivity.this, prescripClassList);

        listView = findViewById(R.id.List);
        Query pendingTestsQuery = databaseReference.orderByChild("name").equalTo("Khairul");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //  Log.e("LOGGGGG","--:"+dataSnapshot.getChildren());
                // String value = dataSnapshot.getValue(String.class);

                // Log.e("LOGGGGG","--:"+value);
                prescripClassList.clear();
                for (DataSnapshot dataSnapshot3 : dataSnapshot.getChildren()) {

                    Map<String, Object> map1 = (Map<String, Object>) dataSnapshot3.getValue();

                    try {
                        JSONObject topobj = new JSONObject(map1);
                        String pName = topobj.getString("name");
                        String pAge = topobj.getString("age");
                        String pBlood = topobj.getString("blood");
                        String m1 = topobj.getString("m1name");
                        String t1 = topobj.getString("time1");
                        String m2 = topobj.getString("m2name");
                        String t2 = topobj.getString("time2");
                        String m3 = topobj.getString("m3name");
                        String t3 = topobj.getString("time3");

                        prescripClass prescription = new prescripClass(pName, pAge,pBlood,m1, t1, m2, t2, m3, t3);
                        prescripClassList.add(prescription);
                        Log.d("TAGGG", "Value is: " + pName);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                    // Log.d(TAG, "Value is: " + map);
                    //   String value = dataSnapshot1.getValue(String.class);
                    //User user = dataSnapshot1.getValue(User.class);
                    Log.e("LOGGGGG", "Value is: " + map1);


                }
                listView.setAdapter(prescripAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("LOGGGGG", "--:" + error.toString());

            }
        });
    }

}