package com.amarapps.healthmonitoring;

import android.app.ProgressDialog;
import android.content.Intent;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;


public class LoginActivity extends AppCompatActivity {
    EditText userName, password;
    Button login;
    TextView register, forgotPassword;
    DatabaseReference databaseReference;
    ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);
        userName = (EditText) findViewById(R.id.userName);
        password = (EditText) findViewById(R.id.pwd);
        login = (Button) findViewById(R.id.login_btn);
        register = (TextView) findViewById(R.id.registerLink);
        forgotPassword = (TextView) findViewById(R.id.ForgetPassword);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        loadingBar = new ProgressDialog(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                //  Toast.makeText(LoginActivity.this,"User Name or Password is Incorrect",Toast.LENGTH_SHORT).show();

                AllowUserToLogin();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendUserToRegister();
            }
        });
        //if user forgets the password then to reset it
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetPasswordUser();
            }
        });


    }

    void resetPasswordUser() {
        String email = userName.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(LoginActivity.this, "Please enter your email id", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(LoginActivity.this, "This feature is Developing ....", Toast.LENGTH_SHORT).show();
        }
    }

    void sendUserToRegister() {
        //When user wants to create a new account send user to Register Activity
        Intent registerIntent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(registerIntent);
    }

    private void AllowUserToLogin() {

        String input1 = userName.getText().toString().trim();
        String input2 = password.getText().toString();
        if (TextUtils.isEmpty(input1)) {
            Toast.makeText(LoginActivity.this, "Please enter userName", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(input2)) {
            Toast.makeText(LoginActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
        } else {

//            if(email.equals("Admin")&& pwd.equals("Admin") ) {
//                Intent mainIntent = new Intent(LoginActivity.this, MainActivity.class);
//                startActivity(mainIntent);
//            }else{
//                Toast.makeText(LoginActivity.this,"User Name or Password is Incorrect",Toast.LENGTH_SHORT).show();
//
//            }

            login();
        }
    }

    void login() {

        databaseReference.child("user").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String input1 = userName.getText().toString();
                String input2 = password.getText().toString();
                Log.i("LOGGGGG", "---300-" + dataSnapshot.toString());
                Log.i("LOGGGGG", "---300-" + input1.toString());
                Log.i("LOGGGGG", "---300-" + input2.toString());
                //if (dataSnapshot.child(input1).child("password").getValue(String.class).equals(input2)) {
                // if (dataSnapshot.child(input1).exists()) {
                boolean isLogin = false;
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                    Map<String, Object> map = (Map<String, Object>) dataSnapshot1.getValue();

                    try {
                        JSONObject topobj = new JSONObject(map);
                        String pass = topobj.getString("pass");
                        String phone = topobj.getString("phone");
                        String userName = topobj.getString("userName");
                        new DataPreference(LoginActivity.this).setPhone(phone);
                        new DataPreference(LoginActivity.this).setUserName(userName);
                        if (pass.equals(input2) && userName.equals(input1)) {
                            sendToMainActivity();
                            break;
                        }
                        Log.d("TAGGGG", "Value is: " + pass);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Log.e("LOGGGGG", "Value is: " + map);


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    private void sendToMainActivity() {
        //This is to send user to MainActivity
        Intent MainIntent = new Intent(LoginActivity.this, NavActivity.class);
        startActivity(MainIntent);
    }
}