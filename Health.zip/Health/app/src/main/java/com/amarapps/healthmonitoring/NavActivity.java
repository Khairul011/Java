package com.amarapps.healthmonitoring;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;

import com.amarapps.healthmonitoring.doctor.DoctorActivity;
import com.amarapps.healthmonitoring.doctor.PrescriptionActivity;
import com.amarapps.healthmonitoring.monitor.MonitorActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class NavActivity extends AppCompatActivity {

   TextView H_name, H_phone;
    DatabaseReference databaseReference;

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav);


        databaseReference = FirebaseDatabase.getInstance().getReference();
        retriveData();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = (TextView) headerView.findViewById(R.id.h_name);
        TextView navPhone = (TextView) headerView.findViewById(R.id.h_phone);
        navUsername.setText(new DataPreference(NavActivity.this).getUserName());
        navPhone.setText(new DataPreference(NavActivity.this).getPhone());
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_profile, R.id.nav_about, R.id.nav_contact,R.id.nav_share)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.nav, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void logut_btn(MenuItem item) {
        startActivity(new Intent(this,LoginActivity.class));

      new DataPreference(this).setAddress("");
      new DataPreference(this).setBlood("");
      new DataPreference(this).setAge("");
      new DataPreference(this).setGender("");
      new DataPreference(this).setTemp("");
      new DataPreference(this).setHeartRate("");
      new DataPreference(this).setSpo2("");
      new DataPreference(this).setEcg("");
        new DataPreference(this).setName("");
        new DataPreference(this).setAge("");
        new DataPreference(this).setBlood("");
        new DataPreference(this).setM1name("");
        new DataPreference(this).setM2name("");
        new DataPreference(this).setM3name("");
        new DataPreference(this).setTime1("");
        new DataPreference(this).setTime2("");
        new DataPreference(this).setTime3("");


        finish();
    }

    @Override
    protected void onResume() {
//        H_name = (TextView) findViewById(R.id.h_name);
//        H_phone = (TextView) findViewById(R.id.h_phone);
//
//        H_name.setText("new DataPreference(NavActivity.this).getUserName()");
//         H_phone.setText("new DataPreference(NavActivity.this).getPhone()");
        super.onResume();
    }

    void retriveData() {

        databaseReference.child("info").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                Log.i("LOGGGGG", "---300-" + dataSnapshot.toString());
                //     Log.i("LOGGGGG", "---300-" + input1.toString());
                //     Log.i("LOGGGGG", "---300-" + input2.toString());
                //if (dataSnapshot.child(input1).child("password").getValue(String.class).equals(input2)) {
                // if (dataSnapshot.child(input1).exists()) {
                boolean isLogin = false;
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                    Map<String, Object> map = (Map<String, Object>) dataSnapshot1.getValue();

                    try {
                        JSONObject topobj = new JSONObject(map);
                        String name = topobj.getString("name");
                        String phone = topobj.getString("phone");

                        String address = topobj.getString("address");
                        String blood = topobj.getString("blood");
                        String age = topobj.getString("age");
                        String gender = topobj.getString("gender");
                        String temp = topobj.getString("temp");
                        String heartRate = topobj.getString("heartRate");
                        String spo2 = topobj.getString("spo2");
                        String ecg = topobj.getString("ecg");

                        if (name.equals(new DataPreference(NavActivity.this).getUserName()) & phone.equals(new DataPreference(NavActivity.this).getPhone())) {
                            new DataPreference(NavActivity.this).setUserName(name);
                            new DataPreference(NavActivity.this).setPhone(phone);
                            new DataPreference(NavActivity.this).setAddress(address);
                            new DataPreference(NavActivity.this).setBlood(blood);
                            new DataPreference(NavActivity.this).setAge(age);
                            new DataPreference(NavActivity.this).setGender(gender);
                            new DataPreference(NavActivity.this).setTemp(temp);
                            new DataPreference(NavActivity.this).setHeartRate(heartRate);
                            new DataPreference(NavActivity.this).setSpo2(spo2);
                            new DataPreference(NavActivity.this).setEcg(ecg);

                        }
////                        if (name.equals(input1) && phone.equals(input1)) {
////                            sendToMainActivity();
////                            break;
//                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void nav_share(MenuItem item) {
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String shareBody =  "http://play.google.com/store/apps/detail?id=" + getPackageName();
        String shareSub = "Try now";
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share using"));

    }
    public void doctor(MenuItem item) {
        Intent doctorIntent = new Intent(NavActivity.this, DoctorActivity.class);
        startActivity(doctorIntent);
    }

    public void prescription(MenuItem item) {
        Intent prescriptionIntent = new Intent(NavActivity.this, PrescriptionActivity.class);
        startActivity(prescriptionIntent);
    }

    public void monitor(MenuItem item) {
        Intent monitorIntent = new Intent(NavActivity.this, MonitorActivity.class);
        startActivity(monitorIntent);
    }
}