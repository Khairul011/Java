package com.amarapps.healthmonitoring.doctor;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.amarapps.healthmonitoring.R;

import java.util.ArrayList;
import java.util.List;
public class prescripAdapter extends ArrayAdapter<prescripClass> {

    private Activity context2;
    private ArrayList<prescripClass> prescripClassList;

    public prescripAdapter(Activity context2, ArrayList<prescripClass> prescripClassList) {
        super(context2, R.layout.prescrip_layout, prescripClassList);
        this.context2 = context2;
        this.prescripClassList = prescripClassList;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = context2.getLayoutInflater();


        convertView = layoutInflater.inflate(R.layout.item_prescrip, null, true);

        prescripClass prescription = prescripClassList.get(position);
        TextView t1 = convertView.findViewById(R.id.pName);
        TextView t2 = convertView.findViewById(R.id.pAge);
        TextView t3 = convertView.findViewById(R.id.pBlood);
        TextView t4 = convertView.findViewById(R.id.m1);
        TextView t5 = convertView.findViewById(R.id.pt1);
        TextView t6 = convertView.findViewById(R.id.m2);
        TextView t7 = convertView.findViewById(R.id.pt2);
        TextView t8 = convertView.findViewById(R.id.m3);
        TextView t9 = convertView.findViewById(R.id.pt3);

        t1.setText(prescription.getName());
        t2.setText(prescription.getAge());
        t3.setText(prescription.getBlood());
        t4.setText(prescription.getM1Name());
        t5.setText(prescription.getTime1());
        t6.setText(prescription.getM2Name());
        t7.setText(prescription.getTime2());
        t8.setText(prescription.getM3Name());
        t9.setText(prescription.getTime3());


        return convertView;
    }
}
