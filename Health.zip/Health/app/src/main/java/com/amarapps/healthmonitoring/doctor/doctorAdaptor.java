package com.amarapps.healthmonitoring.doctor;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.amarapps.healthmonitoring.R;

import java.util.List;

public class doctorAdaptor extends ArrayAdapter<doctorClass> {

    private Activity context1;
    private List<doctorClass> doctorClassList;

    public doctorAdaptor(Activity context1, List<doctorClass> doctorClassList) {
        super(context1, R.layout.doctor_layout, doctorClassList);
        this.context1 = context1;
        this.doctorClassList = doctorClassList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = context1.getLayoutInflater();


            convertView = layoutInflater.inflate(R.layout.item_doctor, null, true);

            doctorClass doctor = doctorClassList.get(position);
            TextView t1 = convertView.findViewById(R.id.d_name);
            TextView t2 = convertView.findViewById(R.id.d_spacial);
            TextView t3 = convertView.findViewById(R.id.d_email);
            t1.setText(doctor.getName());
            t2.setText(doctor.getSpecial());
            t3.setText(doctor.getEmail());
            return convertView;
        }
    }
