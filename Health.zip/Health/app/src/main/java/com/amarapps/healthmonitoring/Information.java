package com.amarapps.healthmonitoring;

public class Information {
    String name, address, blood, phone, age, gender, temp, heartRate, spo2, ecg;

    public Information(String name, String phone, String address, String blood, String age, String gender, String temp, String heartRate, String spo2, String ecg) {
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.blood = blood;
        this.age = age;
        this.gender = gender;
        this.temp = temp;
        this.heartRate = heartRate;
        this.spo2 = spo2;
        this.ecg = ecg;


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBlood() {
        return blood;
    }

    public void setBlood(String blood) {
        this.blood = blood;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String blood) {
        this.blood = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(String heartRate) {
        this.heartRate = heartRate;
    }


    public String getSpo2() {
        return spo2;
    }

    public void setSpo2(String spo2) {
        this.spo2 = spo2;
    }

    public String getEcg() {
        return ecg;
    }

    public void setEcg(String ecg) {
        this.ecg = ecg;
    }
}
